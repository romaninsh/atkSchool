-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 08, 2012 at 07:13 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_exam`
--

CREATE TABLE IF NOT EXISTS `attendance_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `roll_no` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `status` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `attendance_exam`
--


-- --------------------------------------------------------

--
-- Table structure for table `attendance_hostel`
--

CREATE TABLE IF NOT EXISTS `attendance_hostel` (
  `hosteller_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`hosteller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance_hostel`
--


-- --------------------------------------------------------

--
-- Table structure for table `attendance_school`
--

CREATE TABLE IF NOT EXISTS `attendance_school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` char(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `attendance_school`
--


-- --------------------------------------------------------

--
-- Table structure for table `class_master`
--

CREATE TABLE IF NOT EXISTS `class_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `section` char(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `class_master`
--

INSERT INTO `class_master` (`id`, `name`, `section`) VALUES
(1, 'Fifth', 'A'),
(2, 'Fifth', 'B'),
(3, '10th', 'C'),
(4, '8th', 'D'),
(5, '12', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `complain_master`
--

CREATE TABLE IF NOT EXISTS `complain_master` (
  `complain_id` int(11) NOT NULL AUTO_INCREMENT,
  `hosteller_id` int(11) NOT NULL,
  `complain_text` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `action_taken` varchar(255) NOT NULL,
  `action_date` varchar(255) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`complain_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `complain_master`
--


-- --------------------------------------------------------

--
-- Table structure for table `disease_master`
--

CREATE TABLE IF NOT EXISTS `disease_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hosteller_id` int(11) NOT NULL,
  `disease` varchar(255) NOT NULL,
  `report_date` date DEFAULT NULL,
  `treatment` varchar(255) NOT NULL,
  `treatment_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `disease_master`
--


-- --------------------------------------------------------

--
-- Table structure for table `exam_master`
--

CREATE TABLE IF NOT EXISTS `exam_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `class_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exam_master`
--


-- --------------------------------------------------------

--
-- Table structure for table `exam_timetable`
--

CREATE TABLE IF NOT EXISTS `exam_timetable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exam_timetable`
--


-- --------------------------------------------------------

--
-- Table structure for table `fee_applicable`
--

CREATE TABLE IF NOT EXISTS `fee_applicable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `fee_header_id` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `fee_applicable`
--


-- --------------------------------------------------------

--
-- Table structure for table `fee_deposit_master`
--

CREATE TABLE IF NOT EXISTS `fee_deposit_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fee_id` int(11) NOT NULL,
  `due` int(11) DEFAULT NULL,
  `paid` int(11) DEFAULT NULL,
  ` due_date` date DEFAULT NULL,
  `deposit_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `fee_deposit_master`
--


-- --------------------------------------------------------

--
-- Table structure for table `fee_header`
--

CREATE TABLE IF NOT EXISTS `fee_header` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ftype` varchar(50) NOT NULL,
  `isoptional` bit(1) DEFAULT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `fee_header`
--

INSERT INTO `fee_header` (`id`, `ftype`, `isoptional`, `amount`) VALUES
(1, 'tuition-8th', '1', 20000);

-- --------------------------------------------------------

--
-- Table structure for table `hosteller_outward`
--

CREATE TABLE IF NOT EXISTS `hosteller_outward` (
  `hosteller_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `direction` char(10) NOT NULL,
  `withid` int(11) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`hosteller_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hosteller_outward`
--


-- --------------------------------------------------------

--
-- Table structure for table `hostel_allotement`
--

CREATE TABLE IF NOT EXISTS `hostel_allotement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `hostel_allotement`
--


-- --------------------------------------------------------

--
-- Table structure for table `hostel_master`
--

CREATE TABLE IF NOT EXISTS `hostel_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `building_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `hostel_master`
--

INSERT INTO `hostel_master` (`id`, `building_name`) VALUES
(1, 'A.N.KHOSLA Udaipur');

-- --------------------------------------------------------

--
-- Table structure for table `item_master`
--

CREATE TABLE IF NOT EXISTS `item_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `item_master`
--


-- --------------------------------------------------------

--
-- Table structure for table `party_master`
--

CREATE TABLE IF NOT EXISTS `party_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `party_name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `party_master`
--


-- --------------------------------------------------------

--
-- Table structure for table `result_master`
--

CREATE TABLE IF NOT EXISTS `result_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roll_no` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `marks` int(11) NOT NULL,
  `result` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `result_master`
--


-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE IF NOT EXISTS `rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hostel_id` int(11) NOT NULL,
  `room_no` int(11) NOT NULL,
  `capacity` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `rooms`
--


-- --------------------------------------------------------

--
-- Table structure for table `scholars_master`
--

CREATE TABLE IF NOT EXISTS `scholars_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scholar_no` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `father_name` varchar(50) DEFAULT NULL,
  `mother_name` varchar(50) DEFAULT NULL,
  `dob` date NOT NULL,
  `contact` varchar(10) NOT NULL,
  `p_address` varchar(255) NOT NULL,
  `l_address` varchar(255) DEFAULT NULL,
  `sex` char(1) NOT NULL,
  `category` varchar(10) DEFAULT NULL,
  `guardian1_name` varchar(255) NOT NULL,
  `guardian2_name` varchar(255) DEFAULT NULL,
  `guardian3_name` varchar(255) DEFAULT NULL,
  `guardian1_image` longblob,
  `guardian2_image` longblob,
  `guardian3_image` longblob,
  `student_image` longblob,
  `isActive` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `scholars_master`
--

INSERT INTO `scholars_master` (`id`, `scholar_no`, `fname`, `mname`, `lname`, `father_name`, `mother_name`, `dob`, `contact`, `p_address`, `l_address`, `sex`, `category`, `guardian1_name`, `guardian2_name`, `guardian3_name`, `guardian1_image`, `guardian2_image`, `guardian3_image`, `student_image`, `isActive`) VALUES
(3, 0, 'student 3', NULL, NULL, NULL, NULL, '0000-00-00', '', '', NULL, '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(4, 12, 'hada', '', 'ji', 'father', 'mname', '1970-01-01', 'conatc', '11', '', '', '', '', '', '', NULL, NULL, NULL, NULL, '1'),
(5, 13, 'lokesh', NULL, NULL, NULL, NULL, '0000-00-00', '', '', NULL, '', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1'),
(6, 1234, 'abc', '', '', 'x', 'y', '2012-06-04', '123456', 'udp', '', 'M', 'mn', 'hada', '', '', NULL, NULL, NULL, NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `scholar_guardian`
--

CREATE TABLE IF NOT EXISTS `scholar_guardian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  `relation` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `scholar_guardian`
--


-- --------------------------------------------------------

--
-- Table structure for table `session_master`
--

CREATE TABLE IF NOT EXISTS `session_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `iscurrent` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `session_master`
--

INSERT INTO `session_master` (`id`, `name`, `iscurrent`) VALUES
(6, 'test2', '1'),
(7, 'gzhjaz', '0');

-- --------------------------------------------------------

--
-- Table structure for table `stationary_inward`
--

CREATE TABLE IF NOT EXISTS `stationary_inward` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `cost_rate` int(11) NOT NULL,
  `sale_rate` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `party` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `stationary_inward`
--


-- --------------------------------------------------------

--
-- Table structure for table `stationary_issue`
--

CREATE TABLE IF NOT EXISTS `stationary_issue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `stationary_issue`
--


-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scholar_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `ishostler` bit(1) NOT NULL,
  `roll_no` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `student`
--


-- --------------------------------------------------------

--
-- Table structure for table `subject_class_map`
--

CREATE TABLE IF NOT EXISTS `subject_class_map` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `subject_class_map`
--


-- --------------------------------------------------------

--
-- Table structure for table `subject_master`
--

CREATE TABLE IF NOT EXISTS `subject_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` char(10) DEFAULT NULL,
  `max_marks` varchar(255) NOT NULL,
  `pass_marks` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `subject_master`
--

INSERT INTO `subject_master` (`id`, `name`, `code`, `max_marks`, `pass_marks`) VALUES
(1, 'english', 'EG', '80', '20');
